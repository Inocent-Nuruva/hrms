import { useEffect } from "react";
import { useRouter } from "next/router";

export default function OnboardingDashboardPage() {
  const router = useRouter();

  useEffect(() => {
    void router.replace("/dashboard");
  }, [router]);

  return null;
}
