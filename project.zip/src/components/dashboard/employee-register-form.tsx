"use client"

import * as React from "react"
import { toast } from "sonner"
import { showSuccessAlert } from "@/lib/success-alert"
import ReactFlagsSelect from "react-flags-select"
import {
  BadgeCheckIcon,
  CalendarDaysIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  MailIcon,
  PencilIcon,
  PlusIcon,
  Trash2Icon,
  UserPlus2Icon,
} from "lucide-react"

import {
  createEmployeeProfile,
  getCurrentAdmin,
  getCurrentEmployee,
  listBranches,
  listDepartments,
  listPositions,
  type AdminRecord,
} from "@/lib/admin-api"
import {
  Tabs,
  TabsContent,
  TabsContents,
  TabsList,
  TabsTrigger,
} from "@/components/animate-ui/components/animate/tabs"
import {
  Dialog,
  DialogClose,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogPopup,
  DialogTitle,
} from "@/components/animate-ui/components/base/dialog"
import { Switch } from "@/components/animate-ui/components/base/switch"
import { Button } from "@/components/ui/button"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Calendar } from "@/components/ui/calendar"
import { DatePickerPresets } from "@/components/ui/date-picker-presets"
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { AUTH_STORAGE_KEYS } from "@/utils/constants"
import { asRecord, isLikelyRefreshToken, readString } from "@/utils/token-utils"
import { cn } from "@/lib/utils"

const TOKEN_STORAGE_KEY = "hrms.admin.accessToken"
const LEGACY_TOKEN_STORAGE_KEY = "ess_auth_token"

type RegisterFormState = {
  employeeNo: string
  firstName: string
  middleName: string
  lastName: string
  branch: string
  department: string
  position: string
  gender: string
  maritalStatus: string
  nationality: string
  roleId: string
}

type InitializedRegistrationFields = {
  employeeNo: string
  firstName: string
  middleName: string
  lastName: string
  branch: string
  department: string
  position: string
  roleId: string
}

type ContactFormState = {
  contactType: string
  isPrimary: boolean
  countryIso: string
  phoneNumber: string
  email: string
  notes: string
}

type InviteContactFormState = {
  countryIso: string
  phoneNumber: string
  email: string
}

type AddressFormState = {
  addressType: string
  isPrimary: boolean
  addressLine1: string
  addressLine2: string
  city: string
  state: string
  country: string
  postalCode: string
}

type RelativeFormState = {
  isEmergencyContact: boolean
  isPrimary: boolean
  fullName: string
  relationship: string
  phone: string
  email: string
  address: string
  occupation: string
}

type IdentificationFormState = {
  identificationType: string
  isPrimary: boolean
  identificationNumber: string
  issuedCountry: string
  expiryDate: string
}

type BankAccountFormState = {
  paymentMode: "bank" | "mobile_money"
  isPrimary: boolean
  bankName: string
  accountName: string
  accountNumber: string
  branchName: string
  swiftCode: string
  mobileMoneyProvider: string
}

const EMPTY_FORM: RegisterFormState = {
  employeeNo: "",
  firstName: "",
  middleName: "",
  lastName: "",
  branch: "",
  department: "",
  position: "",
  gender: "",
  maritalStatus: "",
  nationality: "",
  roleId: "",
}

const EMPTY_INITIALIZED_FIELDS: InitializedRegistrationFields = {
  employeeNo: "",
  firstName: "",
  middleName: "",
  lastName: "",
  branch: "",
  department: "",
  position: "",
  roleId: "",
}

const GENDER_OPTIONS = ["Male", "Female", "Non-binary", "Prefer not to say"]
const MARITAL_STATUS_OPTIONS = ["Single", "Married", "Divorced", "Widowed"]
const CONTACT_TYPE_OPTIONS = ["personal", "work"]
const ADDRESS_TYPE_OPTIONS = ["home", "work", "other"]
const RELATIONSHIP_OPTIONS = [
  "parent",
  "spouse",
  "sibling",
  "child",
  "guardian",
  "other",
]
const IDENTIFICATION_TYPE_OPTIONS = [
  "national_id",
  "passport",
  "driving_license",
  "voter_id",
  "other",
]
const MOBILE_MONEY_PROVIDER_OPTIONS = [
  "none",
  "M-Pesa",
  "Airtel Money",
  "Tigo Pesa",
  "Halopesa",
]
const DEFAULT_MOBILE_MONEY_PROVIDER =
  MOBILE_MONEY_PROVIDER_OPTIONS.find((option) => option !== "none") ?? "M-Pesa"
const REGISTRATION_STAFF_ROLE_NAMES = new Set([
  "owner",
  "platformowner",
  "administrator",
  "companyadministrator",
  "hrmanager",
  "managerheadofdepartmenthrmanager",
  "hrofficer",
  "junioremployeehrofficer",
  "itadministrator",
  "midlevelemployeeitadministrator",
])
const ADMIN_ROLE_KEYS = new Set([
  "admin",
  "administrator",
  "super_admin",
  "super-admin",
  "company_admin",
  "company-admin",
  "hr_admin",
  "hr-admin",
  "owner",
  "root",
])

const REGISTRATION_STAFF_ROLE_HINTS = [
  "admin",
  "administrator",
  "owner",
  "hrmanager",
  "hrofficer",
  "manager",
  "itadministrator",
]

const EMPTY_CONTACT: ContactFormState = {
  contactType: "personal",
  isPrimary: false,
  countryIso: "TZ",
  phoneNumber: "",
  email: "",
  notes: "",
}

const EMPTY_INVITE_CONTACT: InviteContactFormState = {
  countryIso: "TZ",
  phoneNumber: "",
  email: "",
}

const EMPTY_ADDRESS: AddressFormState = {
  addressType: "home",
  isPrimary: false,
  addressLine1: "",
  addressLine2: "",
  city: "",
  state: "",
  country: "Tanzania",
  postalCode: "",
}

const EMPTY_RELATIVE: RelativeFormState = {
  isEmergencyContact: false,
  isPrimary: false,
  fullName: "",
  relationship: "",
  phone: "",
  email: "",
  address: "",
  occupation: "",
}

const EMPTY_IDENTIFICATION: IdentificationFormState = {
  identificationType: "national_id",
  isPrimary: false,
  identificationNumber: "",
  issuedCountry: "Tanzania",
  expiryDate: "",
}

const EMPTY_BANK_ACCOUNT: BankAccountFormState = {
  paymentMode: "bank",
  isPrimary: false,
  bankName: "",
  accountName: "",
  accountNumber: "",
  branchName: "",
  swiftCode: "",
  mobileMoneyProvider: "none",
}

const REGISTER_STEP_ORDER = [
  "details",
  "contacts",
  "addresses",
  "relatives",
  "identifications",
  "bankAccounts",
] as const

const REGISTER_STEP_LABELS: Record<RegisterStep, string> = {
  details: "Details",
  contacts: "Contacts",
  addresses: "Addresses",
  relatives: "Relatives",
  identifications: "IDs",
  bankAccounts: "Bank",
}

type RegisterStep = (typeof REGISTER_STEP_ORDER)[number]
type DeleteEntityKind = "contact" | "address" | "relative" | "identification" | "bankAccount"

type CountryIso = "TZ" | "KE" | "UG" | "RW" | "BI" | "ZM" | "ZA" | "GB" | "US"

const COUNTRY_DIAL_BY_ISO: Record<CountryIso, string> = {
  TZ: "+255",
  KE: "+254",
  UG: "+256",
  RW: "+250",
  BI: "+257",
  ZM: "+260",
  ZA: "+27",
  GB: "+44",
  US: "+1",
}

const COUNTRY_LABELS: Record<CountryIso, { primary: string; secondary: string }> = {
  TZ: { primary: "Tanzania", secondary: "+255" },
  KE: { primary: "Kenya", secondary: "+254" },
  UG: { primary: "Uganda", secondary: "+256" },
  RW: { primary: "Rwanda", secondary: "+250" },
  BI: { primary: "Burundi", secondary: "+257" },
  ZM: { primary: "Zambia", secondary: "+260" },
  ZA: { primary: "South Africa", secondary: "+27" },
  GB: { primary: "United Kingdom", secondary: "+44" },
  US: { primary: "United States", secondary: "+1" },
}

function joinPhoneWithCountryCode(countryCode: string, phoneNumber: string) {
  const phone = phoneNumber.trim()
  if (!phone) {
    return ""
  }
  if (phone.startsWith("+")) {
    return phone
  }
  return `${countryCode}${phone}`
}

function getDialCodeForCountry(isoCode: string) {
  if (isoCode in COUNTRY_DIAL_BY_ISO) {
    return COUNTRY_DIAL_BY_ISO[isoCode as keyof typeof COUNTRY_DIAL_BY_ISO]
  }
  return COUNTRY_DIAL_BY_ISO.TZ
}

type RoleOption = {
  id: string
  label: string
  name: string
}

function normalizeRoleText(value: string) {
  return value.trim().toLowerCase().replace(/[\s_-]+/g, "")
}

function decodeBase64Url(input: string) {
  try {
    const normalized = input.replace(/-/g, "+").replace(/_/g, "/")
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=")
    return atob(padded)
  } catch {
    return null
  }
}

function decodeJwtPayload(token: string) {
  const parts = token.split(".")
  if (parts.length !== 3 || !parts[1]) {
    return null
  }

  const decoded = decodeBase64Url(parts[1])
  if (!decoded) {
    return null
  }

  try {
    return asRecord(JSON.parse(decoded))
  } catch {
    return null
  }
}

function resolveDefaultRoleId(roleOptions: RoleOption[]) {
  if (roleOptions.length === 0) {
    return ""
  }

  const exactUser = roleOptions.find(
    (role) =>
      normalizeRoleText(role.name) === "user" ||
      normalizeRoleText(role.label) === "user"
  )
  if (exactUser) {
    return exactUser.id
  }

  const includesUser = roleOptions.find(
    (role) =>
      normalizeRoleText(role.name).includes("user") ||
      normalizeRoleText(role.label).includes("user")
  )
  if (includesUser) {
    return includesUser.id
  }

  return roleOptions[0]?.id ?? ""
}

function toText(value: unknown) {
  return typeof value === "string" && value.trim() ? value.trim() : null
}

function readRecordId(record: AdminRecord | null) {
  if (!record) {
    return null
  }
  const value = record.id
  if (typeof value === "number" && Number.isFinite(value)) {
    return value
  }
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value)
    if (Number.isFinite(parsed)) {
      return parsed
    }
  }
  return null
}

function findRecordByName(records: AdminRecord[], selectedName: string) {
  const normalized = selectedName.trim().toLowerCase()
  if (!normalized) {
    return null
  }

  return (
    records.find(
      (record) => (readString(record, ["name", "title"]) ?? "").trim().toLowerCase() === normalized
    ) ??
    null
  )
}

function toRoleOption(record: AdminRecord): RoleOption | null {
  const idValue = record.id
  const id =
    typeof idValue === "number" || typeof idValue === "string" ? String(idValue) : null
  if (!id) {
    return null
  }

  const name = toText(record.name) ?? `role_${id}`
  const label = toText(record.display_name) ?? name
  return { id, label, name }
}

function normalizeRolesPayload(payload: unknown): AdminRecord[] {
  if (Array.isArray(payload)) {
    return payload.filter((entry): entry is AdminRecord => typeof entry === "object" && entry !== null)
  }
  if (typeof payload !== "object" || payload === null) {
    return []
  }
  const record = payload as AdminRecord
  const nestedCandidates = [record.data, record.items, record.results, record.rows]
  for (const candidate of nestedCandidates) {
    if (Array.isArray(candidate)) {
      return candidate.filter((entry): entry is AdminRecord => typeof entry === "object" && entry !== null)
    }
  }
  return []
}

async function fetchRolesDirect(accessToken: string) {
  const baseUrl = (process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://192.168.1.30:8888").replace(/\/$/, "")
  const endpoint = `${baseUrl}/api/roles`

  // Roles endpoint is auth-protected in this environment.
  const authedResponse = await fetch(endpoint, {
    method: "GET",
    cache: "no-store",
    headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : undefined,
  })
  if (authedResponse.ok) {
    return normalizeRolesPayload((await authedResponse.json()) as unknown)
  }

  // Graceful fallback for environments where roles may be exposed without auth.
  const directResponse = await fetch(endpoint, { method: "GET", cache: "no-store" })
  if (!directResponse.ok) {
    throw new Error(`Request failed with status ${authedResponse.status}`)
  }
  return normalizeRolesPayload((await directResponse.json()) as unknown)
}

function resolveAccessTokenFromStorage() {
  if (typeof window === "undefined") {
    return ""
  }

  const fromDedicatedKey = window.localStorage.getItem(TOKEN_STORAGE_KEY)?.trim() ?? ""
  const authTokensRaw = window.localStorage.getItem(AUTH_STORAGE_KEYS.tokens)
  const legacySessionToken = window.sessionStorage.getItem(LEGACY_TOKEN_STORAGE_KEY)?.trim() ?? ""

  let authAccessToken = ""
  let authRefreshToken = ""

  if (authTokensRaw) {
    try {
      const parsed = JSON.parse(authTokensRaw) as unknown
      if (typeof parsed === "string") {
        authAccessToken = parsed.trim()
      }

      const root = asRecord(parsed)
      const rootTokens = asRecord(root?.tokens)
      const rootData = asRecord(root?.data)
      const rootDataTokens = asRecord(rootData?.tokens)
      const candidates = [root, rootTokens, rootData, rootDataTokens]

      for (const candidate of candidates) {
        const candidateAccess = readString(candidate, ["accessToken", "access_token", "token"])
        const candidateRefresh = readString(candidate, ["refreshToken", "refresh_token"])
        if (candidateRefresh && !authRefreshToken) {
          authRefreshToken = candidateRefresh
        }
        if (
          candidateAccess &&
          !isLikelyRefreshToken(candidateAccess, candidateRefresh ?? authRefreshToken)
        ) {
          authAccessToken = candidateAccess
          break
        }
      }
    } catch {
      authAccessToken = authTokensRaw.trim()
      authRefreshToken = ""
    }
  }

  return (
    authAccessToken ||
    (fromDedicatedKey && !isLikelyRefreshToken(fromDedicatedKey, authRefreshToken)
      ? fromDedicatedKey
      : "") ||
    (legacySessionToken && !isLikelyRefreshToken(legacySessionToken, authRefreshToken)
      ? legacySessionToken
      : "")
  )
}

function readStoredAuthUser() {
  if (typeof window === "undefined") {
    return null
  }

  const raw = window.localStorage.getItem(AUTH_STORAGE_KEYS.user)
  if (!raw) {
    return null
  }

  try {
    return asRecord(JSON.parse(raw))
  } catch {
    return null
  }
}

function resolveInitializedRegistrationFields(
  sources: [AdminRecord | null, AdminRecord | null, AdminRecord | null]
): Omit<InitializedRegistrationFields, "roleId"> & { roleName: string } {
  const [currentEmployee, currentAdmin, storedUser] = sources

  const employeeUser = asRecord(currentEmployee?.user)
  const adminUser = asRecord(currentAdmin?.user)

  const employeeNo =
    readString(currentEmployee, ["employee_no", "employee_number", "employee_code", "employeeId", "user_no"]) ??
    readString(currentAdmin, ["user_no", "employee_no", "employeeId", "employee_id"]) ??
    readString(storedUser, ["employeeId", "employee_id", "employee_no", "user_no"]) ??
    ""

  const firstName =
    readString(currentEmployee, ["first_name", "firstName"]) ??
    readString(employeeUser, ["first_name", "firstName"]) ??
    readString(currentAdmin, ["first_name", "firstName"]) ??
    readString(adminUser, ["first_name", "firstName"]) ??
    ""

  const middleName =
    readString(currentEmployee, ["middle_name", "middleName"]) ??
    readString(employeeUser, ["middle_name", "middleName"]) ??
    readString(currentAdmin, ["middle_name", "middleName"]) ??
    readString(adminUser, ["middle_name", "middleName"]) ??
    ""

  const lastName =
    readString(currentEmployee, ["last_name", "lastName"]) ??
    readString(employeeUser, ["last_name", "lastName"]) ??
    readString(currentAdmin, ["last_name", "lastName"]) ??
    readString(adminUser, ["last_name", "lastName"]) ??
    ""

  const branch =
    readString(asRecord(currentEmployee?.primary_branch), ["name", "branch_name"]) ??
    readString(asRecord(currentEmployee?.branch), ["name", "branch_name"]) ??
    readString(currentEmployee, ["branch_name", "branch"]) ??
    ""

  const department =
    readString(asRecord(currentEmployee?.primary_department), ["name", "department_name"]) ??
    readString(asRecord(currentEmployee?.department), ["name", "department_name"]) ??
    readString(currentEmployee, ["department_name", "department"]) ??
    ""

  const position =
    readString(asRecord(currentEmployee?.primary_position), ["name", "position_name"]) ??
    readString(asRecord(currentEmployee?.position), ["name", "position_name"]) ??
    readString(currentEmployee, ["position_name", "position", "designation_name"]) ??
    ""

  const roleName =
    readString(currentAdmin, ["role", "role_name", "user_type"]) ??
    readString(adminUser, ["role", "role_name", "user_type"]) ??
    readString(storedUser, ["role", "role_name", "user_type"]) ??
    ""

  return {
    employeeNo,
    firstName,
    middleName,
    lastName,
    branch,
    department,
    position,
    roleName,
  }
}

function resolveInitializedRoleId(
  roleOptions: RoleOption[],
  sources: [AdminRecord | null, AdminRecord | null, AdminRecord | null]
) {
  const [currentEmployee, currentAdmin, storedUser] = sources
  const directRoleIdCandidates = [
    toText(currentEmployee?.role_id),
    toText(currentAdmin?.role_id),
    toText(storedUser?.role_id),
  ].filter((value): value is string => Boolean(value))

  for (const candidate of directRoleIdCandidates) {
    const match = roleOptions.find((role) => role.id === candidate)
    if (match) {
      return match.id
    }
  }

  const roleName = resolveInitializedRegistrationFields(sources).roleName
  if (!roleName) {
    return ""
  }

  const normalizedRoleName = normalizeRoleText(roleName)
  const byLabel =
    roleOptions.find((role) => normalizeRoleText(role.label) === normalizedRoleName) ??
    roleOptions.find((role) => normalizeRoleText(role.name) === normalizedRoleName) ??
    roleOptions.find(
      (role) =>
        normalizeRoleText(role.label).includes(normalizedRoleName) ||
        normalizedRoleName.includes(normalizeRoleText(role.label)) ||
        normalizeRoleText(role.name).includes(normalizedRoleName) ||
        normalizedRoleName.includes(normalizeRoleText(role.name))
    )

  return byLabel?.id ?? ""
}

function readRoleCandidate(value: unknown): string | null {
  if (typeof value === "string" && value.trim()) {
    return value.trim()
  }
  const record = asRecord(value)
  if (!record) {
    return null
  }
  return (
    readString(record, [
      "name",
      "display_name",
      "label",
      "title",
      "role",
      "role_name",
      "key",
      "code",
      "slug",
      "type",
      "user_type",
    ]) ?? null
  )
}

function collectRoleLabels(record: AdminRecord | null, sink: Set<string>) {
  if (!record) {
    return
  }

  const push = (value: unknown) => {
    const role = readRoleCandidate(value)
    if (role) {
      sink.add(normalizeRoleText(role))
    }
  }

  push(record.role)
  push(record.user_type)
  push(record.type)
  push(record.role_name)
  push(record.roleName)

  for (const candidate of [record.roles, record.authorities, record.userRole, record.user_role]) {
    if (Array.isArray(candidate)) {
      candidate.forEach((entry) => push(entry))
      continue
    }
    push(candidate)
  }
}

function resolveAdminFlag(record: AdminRecord | null) {
  if (!record) {
    return false
  }

  const candidates = [
    record.is_admin,
    record.isAdmin,
    record.admin,
    record.is_super_admin,
    record.isSuperAdmin,
    record.super_admin,
    record.superAdmin,
  ]

  return candidates.some((value) => value === true || value === 1 || value === "1" || value === "true")
}

function canManageOtherEmployees(
  sources: [AdminRecord | null, AdminRecord | null, AdminRecord | null],
  accessToken: string
) {
  const roleLabels = new Set<string>()
  const decodedToken = decodeJwtPayload(accessToken)
  const records = [...sources, decodedToken]

  records.forEach((record) => {
    collectRoleLabels(record, roleLabels)
  })

  if (records.some((record) => resolveAdminFlag(record))) {
    return true
  }

  return Array.from(roleLabels).some(
    (role) =>
      REGISTRATION_STAFF_ROLE_NAMES.has(role) ||
      ADMIN_ROLE_KEYS.has(role) ||
      REGISTRATION_STAFF_ROLE_HINTS.some((hint) => role.includes(hint))
  )
}

const REGISTER_DRAFT_STORAGE_KEY = "hrms.employee.register.draft.v1"

function countryNameFromIso(isoCode: string) {
  try {
    const regionNames = new Intl.DisplayNames(["en"], { type: "region" })
    return regionNames.of(isoCode.toUpperCase()) ?? isoCode.toUpperCase()
  } catch {
    return isoCode.toUpperCase()
  }
}

function AnimatedField({
  delayMs,
  children,
  className,
}: {
  delayMs: number
  children: React.ReactNode
  className?: string
}) {
  return (
    <div
      className={cn("animate-fade-up", className)}
      style={{ animationDelay: `${delayMs}ms`, opacity: 0 }}
    >
      {children}
    </div>
  )
}

function Field({
  label,
  htmlFor,
  delayMs,
  children,
  hint,
  reserveHintSpace = false,
  className,
}: {
  label: string
  htmlFor: string
  delayMs: number
  children: React.ReactNode
  hint?: React.ReactNode
  reserveHintSpace?: boolean
  className?: string
}) {
  return (
    <AnimatedField delayMs={delayMs} className={className}>
      <div className="flex h-full flex-col gap-2">
        <Label htmlFor={htmlFor}>{label}</Label>
        {children}
        {hint || reserveHintSpace ? (
          <div className="min-h-4 text-xs text-muted-foreground">
            {hint}
          </div>
        ) : null}
      </div>
    </AnimatedField>
  )
}

export function EmployeeRegisterForm() {
  const [currentStep, setCurrentStep] = React.useState<RegisterStep>("details")
  const [tabDirection, setTabDirection] = React.useState<"forward" | "backward">("forward")
  const [form, setForm] = React.useState<RegisterFormState>(EMPTY_FORM)
  const [dob, setDob] = React.useState<Date | undefined>(undefined)
  const [contacts, setContacts] = React.useState<ContactFormState[]>([])
  const [addresses, setAddresses] = React.useState<AddressFormState[]>([])
  const [relatives, setRelatives] = React.useState<RelativeFormState[]>([])
  const [identifications, setIdentifications] = React.useState<IdentificationFormState[]>([])
  const [bankAccounts, setBankAccounts] = React.useState<BankAccountFormState[]>([])
  const [isContactDialogOpen, setIsContactDialogOpen] = React.useState(false)
  const [draftContact, setDraftContact] = React.useState<ContactFormState>({ ...EMPTY_CONTACT })
  const [draftContactPhoneError, setDraftContactPhoneError] = React.useState("")
  const [draftContactEmailError, setDraftContactEmailError] = React.useState("")
  const [isInviteMode, setIsInviteMode] = React.useState(false)
  const [inviteContact, setInviteContact] = React.useState<InviteContactFormState>({
    ...EMPTY_INVITE_CONTACT,
  })
  const [invitePhoneError, setInvitePhoneError] = React.useState("")
  const [inviteEmailError, setInviteEmailError] = React.useState("")
  const [editingContactIndex, setEditingContactIndex] = React.useState<number | null>(null)
  const [isAddressDialogOpen, setIsAddressDialogOpen] = React.useState(false)
  const [draftAddress, setDraftAddress] = React.useState<AddressFormState>({ ...EMPTY_ADDRESS })
  const [editingAddressIndex, setEditingAddressIndex] = React.useState<number | null>(null)
  const [isRelativeDialogOpen, setIsRelativeDialogOpen] = React.useState(false)
  const [draftRelative, setDraftRelative] = React.useState<RelativeFormState>({ ...EMPTY_RELATIVE })
  const [editingRelativeIndex, setEditingRelativeIndex] = React.useState<number | null>(null)
  const [isIdentificationDialogOpen, setIsIdentificationDialogOpen] = React.useState(false)
  const [draftIdentification, setDraftIdentification] = React.useState<IdentificationFormState>({
    ...EMPTY_IDENTIFICATION,
  })
  const [editingIdentificationIndex, setEditingIdentificationIndex] = React.useState<number | null>(null)
  const [isBankDialogOpen, setIsBankDialogOpen] = React.useState(false)
  const [draftBankAccount, setDraftBankAccount] = React.useState<BankAccountFormState>({
    ...EMPTY_BANK_ACCOUNT,
  })
  const [editingBankIndex, setEditingBankIndex] = React.useState<number | null>(null)
  const [pendingDelete, setPendingDelete] = React.useState<{
    kind: DeleteEntityKind
    index: number
    label: string
  } | null>(null)
  const [roles, setRoles] = React.useState<RoleOption[]>([])
  const [branchRecords, setBranchRecords] = React.useState<AdminRecord[]>([])
  const [departmentRecords, setDepartmentRecords] = React.useState<AdminRecord[]>([])
  const [positionRecords, setPositionRecords] = React.useState<AdminRecord[]>([])
  const [rolesLoading, setRolesLoading] = React.useState(false)
  const [rolesError, setRolesError] = React.useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = React.useState(false)
  const [initializedFields, setInitializedFields] = React.useState<InitializedRegistrationFields>(
    EMPTY_INITIALIZED_FIELDS
  )
  const [isRegisteringOthers, setIsRegisteringOthers] = React.useState(false)

  const selectedRoleLabel = React.useMemo(
    () => roles.find((role) => role.id === form.roleId)?.label ?? "",
    [roles, form.roleId]
  )
  const roleDisplayValue = selectedRoleLabel || initializedFields.roleId
  const lockedFields = React.useMemo(
    () => ({
      employeeNo: !isRegisteringOthers && Boolean(initializedFields.employeeNo),
      firstName: false,
      middleName: false,
      lastName: false,
      branch: !isRegisteringOthers && Boolean(initializedFields.branch),
      department: !isRegisteringOthers && Boolean(initializedFields.department),
      position: !isRegisteringOthers && Boolean(initializedFields.position),
      roleId: true,
    }),
    [initializedFields, isRegisteringOthers]
  )
  const branchOptions = React.useMemo(
    () =>
      branchRecords
        .map((row) => readString(row, ["name", "title"]))
        .filter((name) => name !== "-"),
    [branchRecords]
  )
  const departmentOptions = React.useMemo(
    () =>
      departmentRecords
        .map((row) => readString(row, ["name", "title"]))
        .filter((name) => name !== "-"),
    [departmentRecords]
  )
  const positionOptions = React.useMemo(
    () =>
      positionRecords
        .map((row) => readString(row, ["name", "title"]))
        .filter((name) => name !== "-"),
    [positionRecords]
  )
  const currentStepIndex = REGISTER_STEP_ORDER.indexOf(currentStep)
  const visibleRegisterSteps: readonly RegisterStep[] = isInviteMode ? ["details"] : REGISTER_STEP_ORDER
  const visibleCurrentStepIndex = visibleRegisterSteps.indexOf(currentStep as (typeof visibleRegisterSteps)[number])
  const currentVisibleStepIndex = visibleCurrentStepIndex === -1 ? 0 : visibleCurrentStepIndex
  const previousVisibleStep =
    currentVisibleStepIndex > 0 ? visibleRegisterSteps[currentVisibleStepIndex - 1] : null
  const nextVisibleStep =
    currentStepIndex < REGISTER_STEP_ORDER.length - 1
      ? visibleRegisterSteps[currentVisibleStepIndex + 1] ?? null
      : null
  const isDraftBankMobileMoney = draftBankAccount.paymentMode === "mobile_money"
  const getStepTransitionClass = React.useCallback(
    (step: RegisterStep) => {
      if (currentStep !== step) {
        return ""
      }
      return tabDirection === "forward"
        ? "animate-in fade-in-0 slide-in-from-right-3 duration-300"
        : "animate-in fade-in-0 slide-in-from-left-3 duration-300"
    },
    [currentStep, tabDirection]
  )

  const updateField = <K extends keyof RegisterFormState>(
    field: K,
    value: RegisterFormState[K]
  ) => {
    setForm((previous) => ({
      ...previous,
      [field]: value,
    }))
  }

  const updateDraftContact = <K extends keyof ContactFormState>(
    field: K,
    value: ContactFormState[K]
  ) => {
    setDraftContact((previous) => ({
      ...previous,
      [field]: value,
    }))
  }

  const updateDraftContactPhone = (nextValue: string) => {
    const digitsOnly = nextValue.replace(/\D/g, "")
    if (digitsOnly.length > 9) {
      setDraftContactPhoneError("Phone number cannot exceed 9 digits.")
      setDraftContact((previous) => ({
        ...previous,
        phoneNumber: digitsOnly.slice(0, 9),
      }))
      return
    }
    setDraftContactPhoneError("")
    setDraftContact((previous) => ({
      ...previous,
      phoneNumber: digitsOnly,
    }))
  }

  const updateInviteContact = <K extends keyof InviteContactFormState>(
    field: K,
    value: InviteContactFormState[K]
  ) => {
    setInviteContact((previous) => ({
      ...previous,
      [field]: value,
    }))
  }

  const updateInvitePhone = (nextValue: string) => {
    const digitsOnly = nextValue.replace(/\D/g, "")
    if (digitsOnly.length > 9) {
      setInvitePhoneError("Phone number cannot exceed 9 digits.")
      setInviteContact((previous) => ({
        ...previous,
        phoneNumber: digitsOnly.slice(0, 9),
      }))
      return
    }
    setInvitePhoneError("")
    setInviteContact((previous) => ({
      ...previous,
      phoneNumber: digitsOnly,
    }))
  }

  const openAddContactDialog = () => {
    setEditingContactIndex(null)
    setDraftContact({ ...EMPTY_CONTACT })
    setDraftContactPhoneError("")
    setDraftContactEmailError("")
    setIsContactDialogOpen(true)
  }

  const openEditContactDialog = (index: number) => {
    const entry = contacts[index]
    if (!entry) {
      return
    }
    setEditingContactIndex(index)
    setDraftContact({ ...entry })
    setDraftContactPhoneError("")
    setDraftContactEmailError("")
    setIsContactDialogOpen(true)
  }

  const saveDraftContact = () => {
    const normalizedPhone = draftContact.phoneNumber.trim()
    const normalizedEmail = draftContact.email.trim().toLowerCase()
    const hasExistingPrimaryWithEmailAndPhone = contacts.some(
      (contact, index) =>
        index !== editingContactIndex &&
        contact.isPrimary &&
        Boolean(contact.phoneNumber.trim()) &&
        Boolean(contact.email.trim())
    )
    const emailRequired = !hasExistingPrimaryWithEmailAndPhone

    if (emailRequired && !normalizedEmail) {
      setDraftContactEmailError("Email is required.")
      return
    }

    if (
      normalizedEmail &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)
    ) {
      setDraftContactEmailError("Enter a valid email address.")
      return
    }

    const nextValue = {
      ...draftContact,
      email: normalizedEmail,
      notes: draftContact.notes.trim(),
      phoneNumber: normalizedPhone,
    }
    setContacts((previous) =>
      editingContactIndex === null
        ? [...previous, nextValue]
        : previous.map((item, index) => (index === editingContactIndex ? nextValue : item))
    )
    setIsContactDialogOpen(false)
    setEditingContactIndex(null)
    setDraftContact({ ...EMPTY_CONTACT })
    setDraftContactPhoneError("")
    setDraftContactEmailError("")
  }

  const removeContact = (index: number) => {
    setContacts((previous) => previous.filter((_, currentIndex) => currentIndex !== index))
  }

  const updateDraftAddress = <K extends keyof AddressFormState>(
    field: K,
    value: AddressFormState[K]
  ) => {
    setDraftAddress((previous) => ({
      ...previous,
      [field]: value,
    }))
  }

  const addAddress = () => {
    setEditingAddressIndex(null)
    setDraftAddress({ ...EMPTY_ADDRESS })
    setIsAddressDialogOpen(true)
  }

  const openEditAddressDialog = (index: number) => {
    const entry = addresses[index]
    if (!entry) {
      return
    }
    setEditingAddressIndex(index)
    setDraftAddress({ ...entry })
    setIsAddressDialogOpen(true)
  }

  const saveDraftAddress = () => {
    setAddresses((previous) =>
      editingAddressIndex === null
        ? [...previous, { ...draftAddress }]
        : previous.map((item, index) => (index === editingAddressIndex ? { ...draftAddress } : item))
    )
    setIsAddressDialogOpen(false)
    setEditingAddressIndex(null)
    setDraftAddress({ ...EMPTY_ADDRESS })
  }

  const removeAddress = (index: number) => {
    setAddresses((previous) => previous.filter((_, currentIndex) => currentIndex !== index))
  }

  const updateDraftRelative = <K extends keyof RelativeFormState>(
    field: K,
    value: RelativeFormState[K]
  ) => {
    setDraftRelative((previous) => ({
      ...previous,
      [field]: value,
    }))
  }

  const addRelative = () => {
    setEditingRelativeIndex(null)
    setDraftRelative({ ...EMPTY_RELATIVE })
    setIsRelativeDialogOpen(true)
  }

  const openEditRelativeDialog = (index: number) => {
    const entry = relatives[index]
    if (!entry) {
      return
    }
    setEditingRelativeIndex(index)
    setDraftRelative({ ...entry })
    setIsRelativeDialogOpen(true)
  }

  const saveDraftRelative = () => {
    setRelatives((previous) =>
      editingRelativeIndex === null
        ? [...previous, { ...draftRelative }]
        : previous.map((item, index) => (index === editingRelativeIndex ? { ...draftRelative } : item))
    )
    setIsRelativeDialogOpen(false)
    setEditingRelativeIndex(null)
    setDraftRelative({ ...EMPTY_RELATIVE })
  }

  const removeRelative = (index: number) => {
    setRelatives((previous) => previous.filter((_, currentIndex) => currentIndex !== index))
  }

  const updateDraftIdentification = <K extends keyof IdentificationFormState>(
    field: K,
    value: IdentificationFormState[K]
  ) => {
    setDraftIdentification((previous) => ({
      ...previous,
      [field]: value,
    }))
  }

  const addIdentification = () => {
    setEditingIdentificationIndex(null)
    setDraftIdentification({ ...EMPTY_IDENTIFICATION })
    setIsIdentificationDialogOpen(true)
  }

  const openEditIdentificationDialog = (index: number) => {
    const entry = identifications[index]
    if (!entry) {
      return
    }
    setEditingIdentificationIndex(index)
    setDraftIdentification({ ...entry })
    setIsIdentificationDialogOpen(true)
  }

  const saveDraftIdentification = () => {
    setIdentifications((previous) =>
      editingIdentificationIndex === null
        ? [...previous, { ...draftIdentification }]
        : previous.map((item, index) =>
            index === editingIdentificationIndex ? { ...draftIdentification } : item
          )
    )
    setIsIdentificationDialogOpen(false)
    setEditingIdentificationIndex(null)
    setDraftIdentification({ ...EMPTY_IDENTIFICATION })
  }

  const removeIdentification = (index: number) => {
    setIdentifications((previous) => previous.filter((_, currentIndex) => currentIndex !== index))
  }

  const updateDraftBankAccount = <K extends keyof BankAccountFormState>(
    field: K,
    value: BankAccountFormState[K]
  ) => {
    setDraftBankAccount((previous) => ({
      ...previous,
      [field]: value,
    }))
  }

  const setDraftBankMode = (useMobileMoney: boolean) => {
    setDraftBankAccount((previous) => {
      if (!useMobileMoney) {
        return {
          ...previous,
          paymentMode: "bank",
          mobileMoneyProvider: "none",
        }
      }

      const nextProvider =
        previous.mobileMoneyProvider && previous.mobileMoneyProvider !== "none"
          ? previous.mobileMoneyProvider
          : DEFAULT_MOBILE_MONEY_PROVIDER

      return {
        ...previous,
        paymentMode: "mobile_money",
        mobileMoneyProvider: nextProvider,
        bankName: nextProvider,
        branchName: "",
      }
    })
  }

  const addBankAccount = () => {
    setEditingBankIndex(null)
    setDraftBankAccount({ ...EMPTY_BANK_ACCOUNT })
    setIsBankDialogOpen(true)
  }

  const openEditBankDialog = (index: number) => {
    const entry = bankAccounts[index]
    if (!entry) {
      return
    }
    const nextMode =
      entry.paymentMode ??
      (entry.mobileMoneyProvider && entry.mobileMoneyProvider !== "none"
        ? "mobile_money"
        : "bank")
    setEditingBankIndex(index)
    setDraftBankAccount({
      ...entry,
      paymentMode: nextMode,
      mobileMoneyProvider:
        entry.mobileMoneyProvider && entry.mobileMoneyProvider !== "none"
          ? entry.mobileMoneyProvider
          : nextMode === "mobile_money"
            ? DEFAULT_MOBILE_MONEY_PROVIDER
            : "none",
    })
    setIsBankDialogOpen(true)
  }

  const saveDraftBankAccount = () => {
    const isMobileMoneyMode = draftBankAccount.paymentMode === "mobile_money"
    const mobileMoneyProvider = isMobileMoneyMode
      ? draftBankAccount.mobileMoneyProvider && draftBankAccount.mobileMoneyProvider !== "none"
        ? draftBankAccount.mobileMoneyProvider
        : DEFAULT_MOBILE_MONEY_PROVIDER
      : "none"

    const normalizedDraft: BankAccountFormState = {
      ...draftBankAccount,
      paymentMode: isMobileMoneyMode ? "mobile_money" : "bank",
      bankName: isMobileMoneyMode
        ? mobileMoneyProvider
        : draftBankAccount.bankName,
      accountNumber: draftBankAccount.accountNumber.trim(),
      branchName: isMobileMoneyMode ? "" : draftBankAccount.branchName,
      swiftCode: draftBankAccount.swiftCode.trim(),
      mobileMoneyProvider,
    }

    setBankAccounts((previous) =>
      editingBankIndex === null
        ? [...previous, normalizedDraft]
        : previous.map((item, index) => (index === editingBankIndex ? normalizedDraft : item))
    )
    setIsBankDialogOpen(false)
    setEditingBankIndex(null)
    setDraftBankAccount({ ...EMPTY_BANK_ACCOUNT })
  }

  const removeBankAccount = (index: number) => {
    setBankAccounts((previous) => previous.filter((_, currentIndex) => currentIndex !== index))
  }

  const requestDelete = (kind: DeleteEntityKind, index: number, label: string) => {
    setPendingDelete({ kind, index, label })
  }

  const confirmDelete = () => {
    if (!pendingDelete) {
      return
    }

    const { kind, index } = pendingDelete
    if (kind === "contact") {
      removeContact(index)
    } else if (kind === "address") {
      removeAddress(index)
    } else if (kind === "relative") {
      removeRelative(index)
    } else if (kind === "identification") {
      removeIdentification(index)
    } else if (kind === "bankAccount") {
      removeBankAccount(index)
    }

    setPendingDelete(null)
  }

  const loadRoles = React.useCallback(async () => {
    const accessToken = resolveAccessTokenFromStorage()
    if (!accessToken) {
      setRoles([])
      setRolesError("Please login again to load roles.")
      return
    }

    setRolesLoading(true)
    setRolesError(null)
    try {
      const [roleRecordsResult, branchResult, departmentResult, positionResult] = await Promise.allSettled([
        fetchRolesDirect(accessToken),
        listBranches(accessToken, { page: 1, limit: 100 }),
        listDepartments(accessToken, { page: 1, limit: 100 }),
        listPositions(accessToken, { page: 1, limit: 100 }),
      ])
      const roleRecords =
        roleRecordsResult.status === "fulfilled" ? roleRecordsResult.value : ([] as AdminRecord[])
      const resolvedBranches = branchResult.status === "fulfilled" ? branchResult.value.rows : []
      const resolvedDepartments =
        departmentResult.status === "fulfilled" ? departmentResult.value.rows : []
      const resolvedPositions = positionResult.status === "fulfilled" ? positionResult.value.rows : []
      const roleOptions = roleRecords
        .map((record) => toRoleOption(record))
        .filter((entry): entry is RoleOption => Boolean(entry))
      setRoles(roleOptions)
      setBranchRecords(resolvedBranches)
      setDepartmentRecords(resolvedDepartments)
      setPositionRecords(resolvedPositions)
      if (roleOptions.length === 0) {
        setRolesError("Roles are unavailable for this account. You can still continue.")
      }
      const defaultRoleId = resolveDefaultRoleId(roleOptions)
      setForm((previous) => {
        const hasCurrent = roleOptions.some((role) => role.id === previous.roleId)
        if (hasCurrent) {
          return previous
        }
        return {
          ...previous,
          roleId: defaultRoleId,
        }
      })
    } catch (errorObject) {
      setRoles([])
      setRolesError(
        errorObject instanceof Error ? errorObject.message : "Failed to load registration data."
      )
    } finally {
      setRolesLoading(false)
    }
  }, [])

  React.useEffect(() => {
    void loadRoles()
  }, [loadRoles])

  React.useEffect(() => {
    const accessToken = resolveAccessTokenFromStorage()
    if (!accessToken) {
      setInitializedFields(EMPTY_INITIALIZED_FIELDS)
      setIsInviteMode(false)
      return
    }

    let isActive = true

    const hydrateInitializedFields = async () => {
      const storedUser = readStoredAuthUser()
      const [currentAdminResult, currentEmployeeResult] = await Promise.allSettled([
        getCurrentAdmin(accessToken),
        getCurrentEmployee(accessToken),
      ])

      if (!isActive) {
        return
      }

      const currentAdmin =
        currentAdminResult.status === "fulfilled" ? currentAdminResult.value : null
      const currentEmployee =
        currentEmployeeResult.status === "fulfilled" ? currentEmployeeResult.value : null
      const initializationSources: [AdminRecord | null, AdminRecord | null, AdminRecord | null] = [
        currentEmployee,
        currentAdmin,
        storedUser,
      ]
      const registeringOthers = canManageOtherEmployees(initializationSources, accessToken)
      setIsRegisteringOthers(registeringOthers)

      if (registeringOthers) {
        setInitializedFields(EMPTY_INITIALIZED_FIELDS)
        setForm((previous) => ({
          ...previous,
          employeeNo: "",
          firstName: "",
          middleName: "",
          lastName: "",
          branch: "",
          department: "",
          position: "",
          roleId: previous.roleId || resolveDefaultRoleId(roles),
        }))
        return
      }

      setIsInviteMode(false)

      const nextInitializedFields = resolveInitializedRegistrationFields(initializationSources)
      const nextRoleId = roles.length > 0 ? resolveInitializedRoleId(roles, initializationSources) : ""

      setInitializedFields({
        ...nextInitializedFields,
        roleId: nextRoleId,
      })

      setForm((previous) => ({
        ...previous,
        employeeNo: nextInitializedFields.employeeNo || previous.employeeNo,
        firstName: nextInitializedFields.firstName || previous.firstName,
        middleName: nextInitializedFields.middleName || previous.middleName,
        lastName: nextInitializedFields.lastName || previous.lastName,
        branch: nextInitializedFields.branch || previous.branch,
        department: nextInitializedFields.department || previous.department,
        position: nextInitializedFields.position || previous.position,
        roleId: nextRoleId || previous.roleId,
      }))
    }

    void hydrateInitializedFields()

    return () => {
      isActive = false
    }
  }, [roles])

  React.useEffect(() => {
    if (!isRegisteringOthers && isInviteMode) {
      setIsInviteMode(false)
    }
  }, [isInviteMode, isRegisteringOthers])

  React.useEffect(() => {
    if (typeof window === "undefined") return
    try {
      const raw = window.localStorage.getItem(REGISTER_DRAFT_STORAGE_KEY)
      if (!raw) return
      const parsed = JSON.parse(raw) as {
        currentStep?: RegisterStep
        isInviteMode?: boolean
        form?: RegisterFormState
        dob?: string | null
        inviteContact?: InviteContactFormState
        contacts?: ContactFormState[]
        addresses?: AddressFormState[]
        relatives?: RelativeFormState[]
        identifications?: IdentificationFormState[]
        bankAccounts?: BankAccountFormState[]
      }
      if (parsed.currentStep && REGISTER_STEP_ORDER.includes(parsed.currentStep)) {
        setCurrentStep(parsed.currentStep)
      }
      if (typeof parsed.isInviteMode === "boolean" && isRegisteringOthers) {
        setIsInviteMode(parsed.isInviteMode)
      }
      if (parsed.form) {
        setForm((previous) => ({ ...previous, ...parsed.form }))
      }
      if (parsed.inviteContact) {
        setInviteContact((previous) => ({ ...previous, ...parsed.inviteContact }))
      }
      if (parsed.dob) {
        const nextDob = new Date(parsed.dob)
        if (!Number.isNaN(nextDob.getTime())) {
          setDob(nextDob)
        }
      }
      if (Array.isArray(parsed.contacts)) setContacts(parsed.contacts)
      if (Array.isArray(parsed.addresses)) setAddresses(parsed.addresses)
      if (Array.isArray(parsed.relatives)) setRelatives(parsed.relatives)
      if (Array.isArray(parsed.identifications)) setIdentifications(parsed.identifications)
      if (Array.isArray(parsed.bankAccounts)) setBankAccounts(parsed.bankAccounts)
    } catch {
      // ignore corrupted draft
    }
  }, [isRegisteringOthers])

  React.useEffect(() => {
    if (typeof window === "undefined") return
    const payload = {
      currentStep,
      isInviteMode,
      form,
      dob: dob ? dob.toISOString() : null,
      inviteContact,
      contacts,
      addresses,
      relatives,
      identifications,
      bankAccounts,
    }
    window.localStorage.setItem(REGISTER_DRAFT_STORAGE_KEY, JSON.stringify(payload))
  }, [currentStep, isInviteMode, form, dob, inviteContact, contacts, addresses, relatives, identifications, bankAccounts])

  const submitRegistration = async () => {
    if (isSubmitting) {
      return
    }

    const accessToken = resolveAccessTokenFromStorage()
    if (!accessToken) {
      toast.error("Authentication required. Please login again.")
      return
    }

    if (!form.firstName.trim() || !form.lastName.trim()) {
      toast.error("First name and last name are required.")
      return
    }
    if (isInviteMode && !form.middleName.trim()) {
      toast.error("Middle name is required for send invite.")
      return
    }

    const normalizedEmployeeNo = ""

    if (isInviteMode && !form.branch.trim()) {
      toast.error("Branch is required for send invite.")
      return
    }

    if (!form.department.trim()) {
      setCurrentStep("details")
      toast.error("Department is required.")
      return
    }

    if (isInviteMode && !form.position.trim()) {
      toast.error("Position is required for send invite.")
      return
    }

    let normalizedContacts: Array<{
      contact_type: string
      is_primary: boolean
      phone_number: string
      email: string
      notes: string
    }> = []

    if (isInviteMode) {
      const normalizedInviteEmail = inviteContact.email.trim().toLowerCase()
      const normalizedInvitePhone = inviteContact.phoneNumber.trim()
      if (!normalizedInvitePhone) {
        toast.error("Phone number is required for send invite.")
        return
      }
      if (!normalizedInviteEmail) {
        toast.error("Email is required for send invite.")
        return
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedInviteEmail)) {
        toast.error("Enter a valid email address for send invite.")
        return
      }
      normalizedContacts = [
        {
          contact_type: "work",
          is_primary: true,
          phone_number: joinPhoneWithCountryCode(
            getDialCodeForCountry(inviteContact.countryIso),
            normalizedInvitePhone
          ),
          email: normalizedInviteEmail,
          notes: "Created from send invite flow.",
        },
      ]
    } else {
      normalizedContacts = contacts
        .map((contact) => ({
          contact_type: contact.contactType.trim() || "personal",
          is_primary: contact.isPrimary,
          phone_number: joinPhoneWithCountryCode(
            getDialCodeForCountry(contact.countryIso),
            contact.phoneNumber
          ),
          email: contact.email.trim().toLowerCase(),
          notes: contact.notes.trim(),
        }))
        .filter((contact) => Boolean(contact.email))

      if (normalizedContacts.length === 0) {
        setCurrentStep("contacts")
        toast.error("At least one contact is required before saving employee.")
        return
      }
    }

    const normalizedAddresses = addresses
      .map((address) => ({
        address_type: address.addressType.trim() || "home",
        is_primary: address.isPrimary,
        address_line_1: address.addressLine1.trim(),
        address_line_2: address.addressLine2.trim(),
        city: address.city.trim(),
        state: address.state.trim(),
        country: address.country.trim(),
        postal_code: address.postalCode.trim(),
      }))
      .filter(
        (address) =>
          address.address_line_1 ||
          address.address_line_2 ||
          address.city ||
          address.state ||
          address.country ||
          address.postal_code ||
          address.is_primary
      )

    const normalizedRelatives = relatives
      .map((relative) => ({
        is_emergency_contact: relative.isEmergencyContact,
        is_primary: relative.isPrimary,
        full_name: relative.fullName.trim(),
        relationship: relative.relationship.trim(),
        phone: relative.phone.trim(),
        email: relative.email.trim(),
        address: relative.address.trim(),
        occupation: relative.occupation.trim(),
      }))
      .filter(
        (relative) =>
          relative.full_name ||
          relative.relationship ||
          relative.phone ||
          relative.email ||
          relative.address ||
          relative.occupation ||
          relative.is_emergency_contact ||
          relative.is_primary
      )

    const normalizedIdentifications = identifications
      .map((idDoc) => ({
        identification_type: idDoc.identificationType.trim() || "national_id",
        is_primary: idDoc.isPrimary,
        identification_number: idDoc.identificationNumber.trim(),
        issued_country: idDoc.issuedCountry.trim(),
        expiry_date: idDoc.expiryDate || "",
      }))
      .filter(
        (idDoc) =>
          idDoc.identification_number ||
          idDoc.issued_country ||
          idDoc.expiry_date ||
          idDoc.is_primary
      )

    const normalizedBankAccounts = bankAccounts
      .map((bank) => ({
        is_primary: bank.isPrimary,
        bank_name: bank.bankName.trim(),
        account_name: bank.accountName.trim(),
        account_number: bank.accountNumber.trim(),
        branch_name: bank.branchName.trim(),
        swift_code: bank.swiftCode.trim(),
        mobile_money_provider:
          bank.mobileMoneyProvider.trim() === "none" ? "" : bank.mobileMoneyProvider.trim(),
      }))
      .filter(
        (bank) =>
          bank.bank_name ||
          bank.account_name ||
          bank.account_number ||
          bank.branch_name ||
          bank.swift_code ||
          bank.mobile_money_provider ||
          bank.is_primary
        )

    const selectedBranchRecord = findRecordByName(branchRecords, form.branch)
    const selectedDepartmentRecord = findRecordByName(departmentRecords, form.department)
    const selectedPositionRecord = findRecordByName(positionRecords, form.position)
    const selectedBranchId = readRecordId(selectedBranchRecord)
    const selectedDepartmentId = readRecordId(selectedDepartmentRecord)
    const selectedPositionId = readRecordId(selectedPositionRecord)
    const selectedDesignationId = (() => {
      if (!selectedPositionRecord) {
        return null
      }
      const raw = selectedPositionRecord.designation_id
      if (typeof raw === "number" && Number.isFinite(raw)) {
        return raw
      }
      if (typeof raw === "string" && raw.trim()) {
        const parsed = Number(raw)
        if (Number.isFinite(parsed)) {
          return parsed
        }
      }
      return null
    })()

    setIsSubmitting(true)
    try {
      await createEmployeeProfile(accessToken, {
        employee_no: normalizedEmployeeNo,
        employment_status: "onboarding",
        employment_type: "full_time",
        primary_branch_id: selectedBranchId ?? undefined,
        primary_department_id: selectedDepartmentId ?? undefined,
        primary_position_id: selectedPositionId ?? undefined,
        primary_designation_id: selectedDesignationId ?? undefined,
        position_id: selectedPositionId ?? undefined,
        first_name: form.firstName.trim(),
        middle_name: form.middleName.trim(),
        last_name: form.lastName.trim(),
        gender: form.gender || undefined,
        marital_status: form.maritalStatus || undefined,
        nationality: form.nationality || undefined,
        date_of_birth: dob ? dob.toISOString().slice(0, 10) : undefined,
        departments: selectedDepartmentId
          ? [
              {
                department_id: selectedDepartmentId,
                is_primary: true,
              },
            ]
          : undefined,
        contacts: normalizedContacts,
        addresses: normalizedAddresses,
        relatives: normalizedRelatives,
        identifications: normalizedIdentifications,
        bank_accounts: normalizedBankAccounts,
        metadata: {
          branch_name: form.branch || undefined,
          department_name: form.department || undefined,
          position_name: form.position || undefined,
          role_id: form.roleId || undefined,
          registration_mode: isInviteMode ? "send_invite" : "full_registration",
        },
      })
      showSuccessAlert(isInviteMode ? "Employee invite saved successfully." : "Employee saved successfully.")
      clearForm()
    } catch (errorObject) {
      toast.error(errorObject instanceof Error ? errorObject.message : "Failed to save employee.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const clearForm = () => {
    setCurrentStep("details")
    setForm({
      ...EMPTY_FORM,
      roleId: resolveDefaultRoleId(roles),
    })
    setIsInviteMode(false)
    setInviteContact({ ...EMPTY_INVITE_CONTACT })
    setInvitePhoneError("")
    setInviteEmailError("")
    setDob(undefined)
    setContacts([])
    setAddresses([])
    setRelatives([])
    setIdentifications([])
    setBankAccounts([])
    setDraftContact({ ...EMPTY_CONTACT })
    setDraftContactPhoneError("")
    setDraftContactEmailError("")
    setIsContactDialogOpen(false)
    setEditingContactIndex(null)
    setDraftAddress({ ...EMPTY_ADDRESS })
    setIsAddressDialogOpen(false)
    setEditingAddressIndex(null)
    setDraftRelative({ ...EMPTY_RELATIVE })
    setIsRelativeDialogOpen(false)
    setEditingRelativeIndex(null)
    setDraftIdentification({ ...EMPTY_IDENTIFICATION })
    setIsIdentificationDialogOpen(false)
    setEditingIdentificationIndex(null)
    setDraftBankAccount({ ...EMPTY_BANK_ACCOUNT })
    setIsBankDialogOpen(false)
    setEditingBankIndex(null)
      setPendingDelete(null)
      if (typeof window !== "undefined") {
        window.localStorage.removeItem(REGISTER_DRAFT_STORAGE_KEY)
      }
    toast.message("Form reset.")
  }

  return (
    <div className="px-4 lg:px-6">
      <Card className="animate-card-entrance overflow-visible">
        <CardHeader className="border-b">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <CardTitle className="flex items-center gap-2">
              <UserPlus2Icon className="size-4" />
              Employee Registration
            </CardTitle>
            {isRegisteringOthers ? (
              <Button
                type="button"
                variant={isInviteMode ? "default" : "outline"}
                onClick={() => {
                  setIsInviteMode((previous) => !previous)
                  setCurrentStep("details")
                }}
              >
                <MailIcon />
                {isInviteMode ? "Back To Full Registration" : "Send Invite"}
              </Button>
            ) : null}
          </div>
        </CardHeader>

        <CardContent className="space-y-7 px-4 pb-7 pt-6 sm:px-5 lg:px-6">
          <Tabs
            value={currentStep}
            onValueChange={(value) => {
              if (REGISTER_STEP_ORDER.includes(value as RegisterStep)) {
                const nextStep = value as RegisterStep
                const nextIndex = REGISTER_STEP_ORDER.indexOf(nextStep)
                if (nextIndex !== -1 && nextIndex !== currentStepIndex) {
                  setTabDirection(nextIndex > currentStepIndex ? "forward" : "backward")
                }
                setCurrentStep(nextStep)
              }
            }}
          >
            <TabsList className="relative !h-auto min-h-9 w-full flex-nowrap items-stretch justify-start gap-0 overflow-x-auto rounded-lg border border-border/70 bg-muted/20 p-0.5 sm:overflow-hidden">
              <div
                aria-hidden="true"
                className="pointer-events-none absolute top-0.5 bottom-0.5 left-0 z-0 rounded-md bg-primary shadow-sm transition-transform duration-500 ease-in-out"
                style={{
                  width: `${100 / visibleRegisterSteps.length}%`,
                  transform: `translateX(${currentVisibleStepIndex * 100}%)`,
                }}
              />
              {visibleRegisterSteps.map((step) => (
                <TabsTrigger
                  key={step}
                  value={step}
                  className="group relative z-10 h-auto min-w-[9rem] flex-none rounded-md border-r border-border/50 px-4 py-2 text-left text-sm data-active:bg-transparent data-active:text-primary-foreground sm:min-w-0 sm:flex-1 [&:last-child]:border-r-0"
                >
                  <span className="flex items-center justify-between gap-2">
                    <span className="flex min-w-0 items-center gap-2">
                      <span className="truncate">{REGISTER_STEP_LABELS[step]}</span>
                    </span>
                  </span>
                </TabsTrigger>
              ))}
            </TabsList>

            <TabsContents className="px-3 pt-6 sm:px-4 lg:px-5 [&_[data-slot=input]]:h-11 [&_[data-slot=input]]:px-4 [&_[data-slot=select-trigger]]:h-11 [&_[data-slot=select-trigger]]:px-4 [&_[data-slot=select-content]]:p-1 [&_[data-slot=select-item]]:px-3 [&_[data-slot=select-item]]:py-2">
              <TabsContent value="details" className={getStepTransitionClass("details")}>
                <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                  <Field label="Employee Number" htmlFor="employeeNo" delayMs={30}>
                    <Input
                      id="employeeNo"
                      value={form.employeeNo}
                      onChange={(event) => updateField("employeeNo", event.target.value)}
                      placeholder="Enter employee number"
                      disabled={lockedFields.employeeNo}
                    />
                  </Field>

                  <Field label="First Name" htmlFor="firstName" delayMs={40}>
                    <Input
                      id="firstName"
                      value={form.firstName}
                      onChange={(event) => updateField("firstName", event.target.value)}
                      placeholder="Enter first name"
                    />
                  </Field>

                  <Field
                    label={isInviteMode ? "Middle Name" : "Middle Name"}
                    htmlFor="middleName"
                    delayMs={80}
                    hint={isInviteMode ? "Required in send invite mode." : undefined}
                    reserveHintSpace={isInviteMode}
                  >
                    <Input
                      id="middleName"
                      value={form.middleName}
                      onChange={(event) => updateField("middleName", event.target.value)}
                      placeholder="Enter middle name"
                    />
                  </Field>

                  <Field label="Last Name" htmlFor="lastName" delayMs={120}>
                    <Input
                      id="lastName"
                      value={form.lastName}
                      onChange={(event) => updateField("lastName", event.target.value)}
                      placeholder="Enter last name"
                    />
                  </Field>

                  <Field label="Branch" htmlFor="branch" delayMs={160}>
                    {lockedFields.branch ? (
                      <Input id="branch" value={form.branch} disabled />
                    ) : (
                      <Select value={form.branch} onValueChange={(value) => updateField("branch", value ?? "")}>
                        <SelectTrigger id="branch" className="w-full">
                          <SelectValue placeholder="Select branch" />
                        </SelectTrigger>
                        <SelectContent>
                          {branchOptions.map((option) => (
                            <SelectItem key={option} value={option}>
                              {option}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </Field>

                  <Field label="Department" htmlFor="department" delayMs={200}>
                    {lockedFields.department ? (
                      <Input id="department" value={form.department} disabled />
                    ) : (
                      <Select
                        value={form.department}
                        onValueChange={(value) => updateField("department", value ?? "")}
                      >
                        <SelectTrigger id="department" className="w-full">
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                        <SelectContent>
                          {departmentOptions.map((option) => (
                            <SelectItem key={option} value={option}>
                              {option}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </Field>

                  <Field label="Position" htmlFor="position" delayMs={240}>
                    {lockedFields.position ? (
                      <Input id="position" value={form.position} disabled />
                    ) : (
                      <Select value={form.position} onValueChange={(value) => updateField("position", value ?? "")}>
                        <SelectTrigger id="position" className="w-full">
                          <SelectValue placeholder="Select position" />
                        </SelectTrigger>
                        <SelectContent>
                          {positionOptions.map((option) => (
                            <SelectItem key={option} value={option}>
                              {option}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </Field>

                  {isInviteMode ? (
                    <>
                      <Field label="Phone Country" htmlFor="invite-country" delayMs={260}>
                        <Select
                          value={inviteContact.countryIso}
                          onValueChange={(value) => updateInviteContact("countryIso", value as CountryIso)}
                        >
                          <SelectTrigger id="invite-country" className="w-full">
                            <SelectValue placeholder="Select country" />
                          </SelectTrigger>
                          <SelectContent>
                            {Object.entries(COUNTRY_LABELS).map(([isoCode, label]) => (
                              <SelectItem key={isoCode} value={isoCode}>
                                {label.primary} ({label.secondary})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </Field>

                      <Field
                        label="Phone Number"
                        htmlFor="invite-phone"
                        delayMs={280}
                        hint={invitePhoneError || "Required for send invite."}
                        reserveHintSpace
                      >
                        <Input
                          id="invite-phone"
                          inputMode="numeric"
                          value={inviteContact.phoneNumber}
                          onChange={(event) => updateInvitePhone(event.target.value)}
                          placeholder="Enter phone number"
                        />
                      </Field>

                      <Field
                        label="Email"
                        htmlFor="invite-email"
                        delayMs={300}
                        hint={inviteEmailError || "Required for send invite."}
                        reserveHintSpace
                      >
                        <Input
                          id="invite-email"
                          type="email"
                          value={inviteContact.email}
                          onChange={(event) => {
                            const nextValue = event.target.value
                            setInviteEmailError("")
                            updateInviteContact("email", nextValue)
                          }}
                          placeholder="Enter email address"
                        />
                      </Field>
                    </>
                  ) : null}

                  {!isInviteMode ? (
                    <>
                      <Field label="Gender" htmlFor="gender" delayMs={280}>
                        <Select value={form.gender} onValueChange={(value) => updateField("gender", value ?? "")}>
                          <SelectTrigger id="gender" className="w-full">
                            <SelectValue placeholder="Select gender" />
                          </SelectTrigger>
                          <SelectContent>
                            {GENDER_OPTIONS.map((option) => (
                              <SelectItem key={option} value={option}>
                                {option}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </Field>

                      <Field label="Marital Status" htmlFor="maritalStatus" delayMs={320}>
                        <Select
                          value={form.maritalStatus}
                          onValueChange={(value) => updateField("maritalStatus", value ?? "")}
                        >
                          <SelectTrigger id="maritalStatus" className="w-full">
                            <SelectValue placeholder="Select marital status" />
                          </SelectTrigger>
                          <SelectContent>
                            {MARITAL_STATUS_OPTIONS.map((option) => (
                              <SelectItem key={option} value={option}>
                                {option}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </Field>

                      <Field
                        label="Nationality"
                        htmlFor="nationality"
                        delayMs={360}
                        hint={form.nationality ? countryNameFromIso(form.nationality) : undefined}
                        reserveHintSpace
                        className="relative z-40 focus-within:z-[140]"
                      >
                        <div className="register-nationality relative z-[70] rounded-md border border-slate-300 px-2 py-2">
                          <ReactFlagsSelect
                            selected={form.nationality || ""}
                            onSelect={(value) => updateField("nationality", value ?? "")}
                            searchable
                            searchPlaceholder="Search country"
                            placeholder="Select nationality"
                            alignOptionsToRight={false}
                            className="w-full"
                            selectButtonClassName="w-full"
                            customLabels={{}}
                          />
                        </div>
                      </Field>

                      <Field
                        label="Roles"
                        htmlFor="roleId"
                        delayMs={400}
                        hint={
                          rolesError ? (
                            <span
                              className={cn(
                                rolesError.includes("unavailable") ? "text-muted-foreground" : "text-destructive"
                              )}
                            >
                              {rolesError}
                            </span>
                          ) : undefined
                        }
                        reserveHintSpace
                      >
                        <Input
                          id="roleId"
                          value={roleDisplayValue}
                          placeholder={rolesLoading ? "Loading role..." : "Assigned automatically"}
                          disabled
                        />
                      </Field>

                      <AnimatedField delayMs={440}>
                        <div className="grid gap-2 md:col-span-2 xl:col-span-3">
                          <Label htmlFor="dob-trigger">Date of Birth</Label>
                          <Popover>
                            <PopoverTrigger
                              id="dob-trigger"
                              className="flex h-9 w-full items-center justify-start gap-2 rounded-lg border border-input bg-background px-3 text-sm outline-none transition-colors hover:bg-muted/40 focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50"
                            >
                              <CalendarDaysIcon className="size-4 text-muted-foreground" />
                              <span className={dob ? "text-foreground" : "text-muted-foreground"}>
                                {dob ? dob.toLocaleDateString() : "Select date from calendar"}
                              </span>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={dob}
                                onSelect={setDob}
                                captionLayout="dropdown"
                                className="rounded-lg border bg-background"
                                fromYear={1940}
                                toYear={new Date().getFullYear()}
                              />
                            </PopoverContent>
                          </Popover>
                        </div>
                      </AnimatedField>
                    </>
                  ) : null}
                </div>
              </TabsContent>

              <TabsContent value="contacts" className={getStepTransitionClass("contacts")}>
                <div className="grid gap-3">
                  <div className="flex items-center justify-between gap-2">
                    <Label>Contacts</Label>
                    {contacts.length > 0 ? (
                      <Button type="button" size="sm" variant="outline" onClick={openAddContactDialog}>
                        <PlusIcon />
                        Add Contact
                      </Button>
                    ) : null}
                  </div>

                  {contacts.length === 0 ? (
                    <div className="rounded-md border border-dashed border-border/80 bg-muted/20 p-6 text-center">
                      <p className="text-sm text-muted-foreground">No contacts added.</p>
                      <Button type="button" size="sm" variant="outline" className="mt-3" onClick={openAddContactDialog}>
                        <PlusIcon />
                        Add Contact
                      </Button>
                    </div>
                  ) : (
                    <div className="grid gap-3">
                      {contacts.map((contact, index) => (
                        <div key={`contact-${index}`} className="rounded-md border border-border/80 bg-card p-3">
                          <div className="flex items-start justify-between gap-3">
                            <div className="grid gap-1">
                              <div className="flex items-center gap-2">
                                <p className="text-sm font-medium">Contact {index + 1}</p>
                                {contact.isPrimary ? (
                                  <span className="inline-flex items-center gap-1 rounded-full border border-emerald-300/70 bg-emerald-100 px-2 py-0.5 text-[11px] font-medium text-emerald-700 dark:border-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300">
                                    <BadgeCheckIcon className="size-3.5" />
                                    Primary
                                  </span>
                                ) : null}
                              </div>
                              <p className="text-sm text-muted-foreground">
                                {contact.contactType} ·{" "}
                                {joinPhoneWithCountryCode(
                                  getDialCodeForCountry(contact.countryIso),
                                  contact.phoneNumber
                                ) || "No phone"}
                              </p>
                              {contact.email ? (
                                <p className="text-xs text-muted-foreground">Email: {contact.email}</p>
                              ) : null}
                              {contact.notes ? (
                                <p className="text-xs text-muted-foreground">Notes: {contact.notes}</p>
                              ) : null}
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                type="button"
                                size="icon-sm"
                                variant="outline"
                                onClick={() => openEditContactDialog(index)}
                                aria-label={`Edit contact ${index + 1}`}
                                title="Edit"
                              >
                                <PencilIcon />
                              </Button>
                              <Button
                                type="button"
                                size="icon-sm"
                                variant="outline"
                                className="border-destructive/30 text-destructive hover:bg-destructive/10"
                                onClick={() => requestDelete("contact", index, `Contact ${index + 1}`)}
                                aria-label={`Delete contact ${index + 1}`}
                                title="Delete"
                              >
                                <Trash2Icon />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="addresses" className={getStepTransitionClass("addresses")}>
                <div className="grid gap-3">
                  <div className="flex items-center justify-between gap-2">
                    <Label>Addresses</Label>
                    {addresses.length > 0 ? (
                      <Button type="button" size="sm" variant="outline" onClick={addAddress}>
                        <PlusIcon />
                        Add Address
                      </Button>
                    ) : null}
                  </div>
                  {addresses.length === 0 ? (
                    <div className="rounded-md border border-dashed border-border/80 bg-muted/20 p-6 text-center">
                      <p className="text-sm text-muted-foreground">No addresses added.</p>
                      <Button type="button" size="sm" variant="outline" className="mt-3" onClick={addAddress}>
                        <PlusIcon />
                        Add Address
                      </Button>
                    </div>
                  ) : (
                    addresses.map((address, index) => (
                      <div key={`address-${index}`} className="rounded-md border border-border/80 bg-card p-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="grid gap-1">
                            <p className="text-sm font-medium">Address {index + 1}</p>
                            <p className="text-sm text-muted-foreground">
                              {address.addressType} · {address.city || "No city"} · {address.country || "No country"}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {address.addressLine1 || "No address line 1"}
                              {address.addressLine2 ? `, ${address.addressLine2}` : ""}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {address.state || "No state"} {address.postalCode ? `· ${address.postalCode}` : ""}
                            </p>
                            {address.isPrimary ? (
                              <p className="inline-flex items-center gap-1 text-xs font-medium text-primary">
                                <BadgeCheckIcon className="size-3.5" />
                                Primary address
                              </p>
                            ) : null}
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              type="button"
                              size="icon-sm"
                              variant="outline"
                              onClick={() => openEditAddressDialog(index)}
                              aria-label={`Edit address ${index + 1}`}
                              title="Edit"
                            >
                              <PencilIcon />
                            </Button>
                            <Button
                              type="button"
                              size="icon-sm"
                              variant="outline"
                              className="border-destructive/30 text-destructive hover:bg-destructive/10"
                              onClick={() => requestDelete("address", index, `Address ${index + 1}`)}
                              aria-label={`Delete address ${index + 1}`}
                              title="Delete"
                            >
                              <Trash2Icon />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </TabsContent>

              <TabsContent value="relatives" className={getStepTransitionClass("relatives")}>
                <div className="grid gap-3">
                  <div className="flex items-center justify-between gap-2">
                    <Label>Relatives</Label>
                    {relatives.length > 0 ? (
                      <Button type="button" size="sm" variant="outline" onClick={addRelative}>
                        <PlusIcon />
                        Add Relative
                      </Button>
                    ) : null}
                  </div>
                  {relatives.length === 0 ? (
                    <div className="rounded-md border border-dashed border-border/80 bg-muted/20 p-6 text-center">
                      <p className="text-sm text-muted-foreground">No relatives added.</p>
                      <Button type="button" size="sm" variant="outline" className="mt-3" onClick={addRelative}>
                        <PlusIcon />
                        Add Relative
                      </Button>
                    </div>
                  ) : (
                    relatives.map((relative, index) => (
                      <div key={`relative-${index}`} className="rounded-md border border-border/80 bg-card p-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="grid gap-1">
                            <p className="text-sm font-medium">Relative {index + 1}</p>
                            <p className="text-sm text-muted-foreground">
                              {relative.fullName || "No name"} · {relative.relationship || "No relationship"}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {relative.phone || "No phone"} · {relative.email || "No email"}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {relative.address || "No address"} · {relative.occupation || "No occupation"}
                            </p>
                            {relative.isEmergencyContact ? (
                              <p className="text-xs font-medium text-primary">Emergency contact</p>
                            ) : null}
                            {relative.isPrimary ? (
                              <p className="inline-flex items-center gap-1 text-xs font-medium text-primary">
                                <BadgeCheckIcon className="size-3.5" />
                                Primary relative
                              </p>
                            ) : null}
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              type="button"
                              size="icon-sm"
                              variant="outline"
                              onClick={() => openEditRelativeDialog(index)}
                              aria-label={`Edit relative ${index + 1}`}
                              title="Edit"
                            >
                              <PencilIcon />
                            </Button>
                            <Button
                              type="button"
                              size="icon-sm"
                              variant="outline"
                              className="border-destructive/30 text-destructive hover:bg-destructive/10"
                              onClick={() => requestDelete("relative", index, `Relative ${index + 1}`)}
                              aria-label={`Delete relative ${index + 1}`}
                              title="Delete"
                            >
                              <Trash2Icon />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </TabsContent>

              <TabsContent value="identifications" className={getStepTransitionClass("identifications")}>
                <div className="grid gap-3">
                  <div className="flex items-center justify-between gap-2">
                    <Label>Identifications</Label>
                    {identifications.length > 0 ? (
                      <Button type="button" size="sm" variant="outline" onClick={addIdentification}>
                        <PlusIcon />
                        Add Identification
                      </Button>
                    ) : null}
                  </div>
                  {identifications.length === 0 ? (
                    <div className="rounded-md border border-dashed border-border/80 bg-muted/20 p-6 text-center">
                      <p className="text-sm text-muted-foreground">No identifications added.</p>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="mt-3"
                        onClick={addIdentification}
                      >
                        <PlusIcon />
                        Add Identification
                      </Button>
                    </div>
                  ) : (
                    identifications.map((idDoc, index) => (
                      <div key={`id-doc-${index}`} className="rounded-md border border-border/80 bg-card p-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="grid gap-1">
                            <p className="text-sm font-medium">Identification {index + 1}</p>
                            <p className="text-sm text-muted-foreground">
                              {idDoc.identificationType} · {idDoc.identificationNumber || "No number"}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {idDoc.issuedCountry || "No issued country"}
                              {idDoc.expiryDate ? ` · Expires ${idDoc.expiryDate}` : ""}
                            </p>
                            {idDoc.isPrimary ? (
                              <p className="inline-flex items-center gap-1 text-xs font-medium text-primary">
                                <BadgeCheckIcon className="size-3.5" />
                                Primary identification
                              </p>
                            ) : null}
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              type="button"
                              size="icon-sm"
                              variant="outline"
                              onClick={() => openEditIdentificationDialog(index)}
                              aria-label={`Edit identification ${index + 1}`}
                              title="Edit"
                            >
                              <PencilIcon />
                            </Button>
                            <Button
                              type="button"
                              size="icon-sm"
                              variant="outline"
                              className="border-destructive/30 text-destructive hover:bg-destructive/10"
                              onClick={() =>
                                requestDelete("identification", index, `Identification ${index + 1}`)
                              }
                              aria-label={`Delete identification ${index + 1}`}
                              title="Delete"
                            >
                              <Trash2Icon />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </TabsContent>

              <TabsContent value="bankAccounts" className={getStepTransitionClass("bankAccounts")}>
                <div className="grid gap-3">
                  <div className="flex items-center justify-between gap-2">
                    <Label>Bank Accounts</Label>
                    {bankAccounts.length > 0 ? (
                      <Button type="button" size="sm" variant="outline" onClick={addBankAccount}>
                        <PlusIcon />
                        Add Bank Account
                      </Button>
                    ) : null}
                  </div>
                  {bankAccounts.length === 0 ? (
                    <div className="rounded-md border border-dashed border-border/80 bg-muted/20 p-6 text-center">
                      <p className="text-sm text-muted-foreground">No bank accounts added.</p>
                      <Button type="button" size="sm" variant="outline" className="mt-3" onClick={addBankAccount}>
                        <PlusIcon />
                        Add Bank Account
                      </Button>
                    </div>
                  ) : (
                    bankAccounts.map((bank, index) => (
                      <div key={`bank-${index}`} className="rounded-md border border-border/80 bg-card p-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="grid gap-1">
                            <p className="text-sm font-medium">Bank Account {index + 1}</p>
                            <p className="text-sm text-muted-foreground">
                              {bank.bankName || "No bank"} · {bank.accountName || "No account name"}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {bank.accountNumber || "No account number"} · {bank.branchName || "No branch"}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {bank.swiftCode || "No SWIFT"}
                              {bank.mobileMoneyProvider && bank.mobileMoneyProvider !== "none"
                                ? ` · ${bank.mobileMoneyProvider}`
                                : ""}
                            </p>
                            {bank.isPrimary ? (
                              <p className="inline-flex items-center gap-1 text-xs font-medium text-primary">
                                <BadgeCheckIcon className="size-3.5" />
                                Primary bank account
                              </p>
                            ) : null}
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              type="button"
                              size="icon-sm"
                              variant="outline"
                              onClick={() => openEditBankDialog(index)}
                              aria-label={`Edit bank account ${index + 1}`}
                              title="Edit"
                            >
                              <PencilIcon />
                            </Button>
                            <Button
                              type="button"
                              size="icon-sm"
                              variant="outline"
                              className="border-destructive/30 text-destructive hover:bg-destructive/10"
                              onClick={() => requestDelete("bankAccount", index, `Bank Account ${index + 1}`)}
                              aria-label={`Delete bank account ${index + 1}`}
                              title="Delete"
                            >
                              <Trash2Icon />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </TabsContent>
            </TabsContents>
          </Tabs>
        </CardContent>

        <CardFooter className="flex flex-wrap justify-between gap-3">
          <Button variant="outline" onClick={clearForm}>
            Clear
          </Button>
          <div className="flex items-center gap-2">
            {previousVisibleStep ? (
              <Button
                variant="outline"
                onClick={() => {
                  setTabDirection("backward")
                  setCurrentStep(previousVisibleStep)
                }}
              >
                <ChevronLeftIcon />
                Previous
              </Button>
            ) : null}

            {nextVisibleStep ? (
              <Button
                onClick={() => {
                  setTabDirection("forward")
                  setCurrentStep(nextVisibleStep)
                }}
              >
                Next
                <ChevronRightIcon />
              </Button>
            ) : (
              <Button onClick={() => void submitRegistration()} disabled={isSubmitting}>
                {isSubmitting ? "Saving..." : isInviteMode ? "Save Invite" : "Save Employee"}
              </Button>
            )}
          </div>
        </CardFooter>
      </Card>

      <AlertDialog
        open={Boolean(pendingDelete)}
        onOpenChange={(open) => {
          if (!open) {
            setPendingDelete(null)
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm delete</AlertDialogTitle>
            <AlertDialogDescription>
              {pendingDelete
                ? `Are you sure you want to delete ${pendingDelete.label}? This action cannot be undone.`
                : "Are you sure you want to delete this item?"}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel />
            <AlertDialogAction onClick={confirmDelete} />
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={isAddressDialogOpen} onOpenChange={setIsAddressDialogOpen}>
        <DialogPopup from="right" className="sm:max-w-[640px]">
          <DialogHeader>
            <DialogTitle>{editingAddressIndex === null ? "Add Address" : "Edit Address"}</DialogTitle>
            <DialogDescription>
              {editingAddressIndex === null
                ? "Capture an address and add it to the list."
                : "Update the selected address."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            <div className="grid gap-2">
              <Label htmlFor="draft-address-type">Address Type</Label>
              <Select
                value={draftAddress.addressType}
                onValueChange={(value) => updateDraftAddress("addressType", value ?? "home")}
              >
                <SelectTrigger id="draft-address-type">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {ADDRESS_TYPE_OPTIONS.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-address-country">Country</Label>
              <Input
                id="draft-address-country"
                value={draftAddress.country}
                onChange={(event) => updateDraftAddress("country", event.target.value)}
                placeholder="Country"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-address-city">City</Label>
              <Input
                id="draft-address-city"
                value={draftAddress.city}
                onChange={(event) => updateDraftAddress("city", event.target.value)}
                placeholder="City"
              />
            </div>
            <div className="grid gap-2 md:col-span-2 xl:col-span-3">
              <Label htmlFor="draft-address-line1">Address Line 1</Label>
              <Input
                id="draft-address-line1"
                value={draftAddress.addressLine1}
                onChange={(event) => updateDraftAddress("addressLine1", event.target.value)}
                placeholder="Street and number"
              />
            </div>
            <div className="grid gap-2 md:col-span-2 xl:col-span-3">
              <Label htmlFor="draft-address-line2">Address Line 2</Label>
              <Input
                id="draft-address-line2"
                value={draftAddress.addressLine2}
                onChange={(event) => updateDraftAddress("addressLine2", event.target.value)}
                placeholder="Apartment, block, landmark"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-address-state">State</Label>
              <Input
                id="draft-address-state"
                value={draftAddress.state}
                onChange={(event) => updateDraftAddress("state", event.target.value)}
                placeholder="State / Region"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-address-postal">Postal Code</Label>
              <Input
                id="draft-address-postal"
                value={draftAddress.postalCode}
                onChange={(event) => updateDraftAddress("postalCode", event.target.value)}
                placeholder="Postal code"
              />
            </div>
            <label className="inline-flex items-center gap-2 text-sm font-medium md:col-span-2 xl:col-span-3">
              <Checkbox
                checked={draftAddress.isPrimary}
                onCheckedChange={(checked) => updateDraftAddress("isPrimary", Boolean(checked))}
              />
              Primary address
            </label>
          </div>
          <DialogFooter>
            <DialogClose render={<Button variant="outline">Cancel</Button>} />
            <Button type="button" onClick={saveDraftAddress}>
              {editingAddressIndex === null ? "Save Address" : "Update Address"}
            </Button>
          </DialogFooter>
        </DialogPopup>
      </Dialog>

      <Dialog open={isRelativeDialogOpen} onOpenChange={setIsRelativeDialogOpen}>
        <DialogPopup from="right" className="sm:max-w-[640px]">
          <DialogHeader>
            <DialogTitle>{editingRelativeIndex === null ? "Add Relative" : "Edit Relative"}</DialogTitle>
            <DialogDescription>
              {editingRelativeIndex === null
                ? "Capture a relative and add to the list."
                : "Update the selected relative."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            <div className="grid gap-2">
              <Label htmlFor="draft-relative-name">Full Name</Label>
              <Input
                id="draft-relative-name"
                value={draftRelative.fullName}
                onChange={(event) => updateDraftRelative("fullName", event.target.value)}
                placeholder="Full name"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-relative-relationship">Relationship</Label>
              <Select
                value={draftRelative.relationship}
                onValueChange={(value) => updateDraftRelative("relationship", value ?? "")}
              >
                <SelectTrigger id="draft-relative-relationship">
                  <SelectValue placeholder="Select relationship" />
                </SelectTrigger>
                <SelectContent>
                  {RELATIONSHIP_OPTIONS.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-relative-phone">Phone</Label>
              <div className="grid gap-2 sm:grid-cols-[220px_minmax(0,1fr)]">
                <Select
                  value={draftRelative.phone.startsWith("+")
                    ? (Object.keys(COUNTRY_DIAL_BY_ISO).find((iso) =>
                        draftRelative.phone.startsWith(
                          COUNTRY_DIAL_BY_ISO[iso as keyof typeof COUNTRY_DIAL_BY_ISO]
                        )
                      ) ?? "TZ")
                    : "TZ"}
                  onValueChange={(isoCode) => {
                    const safeIsoCode = isoCode ?? "TZ"
                    const dial = getDialCodeForCountry(safeIsoCode)
                    const stripped = draftRelative.phone.replace(/^\+\d+/, "").replace(/\D/g, "")
                    updateDraftRelative("phone", `${dial}${stripped}`)
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Country code" />
                  </SelectTrigger>
                  <SelectContent>
                    {(Object.keys(COUNTRY_DIAL_BY_ISO) as CountryIso[]).map((iso) => (
                      <SelectItem key={iso} value={iso}>
                        {COUNTRY_LABELS[iso].primary} ({COUNTRY_LABELS[iso].secondary})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  id="draft-relative-phone"
                  value={draftRelative.phone.replace(/^\+\d+/, "")}
                  onChange={(event) => {
                    const digits = event.target.value.replace(/\D/g, "")
                    const iso =
                      (Object.keys(COUNTRY_DIAL_BY_ISO).find((code) =>
                        draftRelative.phone.startsWith(
                          COUNTRY_DIAL_BY_ISO[code as keyof typeof COUNTRY_DIAL_BY_ISO]
                        )
                      ) as CountryIso | undefined) ?? "TZ"
                    updateDraftRelative("phone", `${getDialCodeForCountry(iso)}${digits}`)
                  }}
                  placeholder="Phone number"
                />
              </div>
            </div>
            <div className="grid gap-2 md:col-span-2 xl:col-span-3">
              <Label htmlFor="draft-relative-email">Email</Label>
              <Input
                id="draft-relative-email"
                type="email"
                value={draftRelative.email}
                onChange={(event) => updateDraftRelative("email", event.target.value)}
                placeholder="user@example.com"
              />
            </div>
            <div className="grid gap-2 md:col-span-2 xl:col-span-3">
              <Label htmlFor="draft-relative-address">Address</Label>
              <Input
                id="draft-relative-address"
                value={draftRelative.address}
                onChange={(event) => updateDraftRelative("address", event.target.value)}
                placeholder="Address"
              />
            </div>
            <div className="grid gap-2 md:col-span-2 xl:col-span-3">
              <Label htmlFor="draft-relative-occupation">Occupation</Label>
              <Input
                id="draft-relative-occupation"
                value={draftRelative.occupation}
                onChange={(event) => updateDraftRelative("occupation", event.target.value)}
                placeholder="Occupation"
              />
            </div>
            <label className="inline-flex items-center gap-2 text-sm font-medium">
              <Checkbox
                checked={draftRelative.isEmergencyContact}
                onCheckedChange={(checked) => updateDraftRelative("isEmergencyContact", Boolean(checked))}
              />
              Emergency contact
            </label>
            <label className="inline-flex items-center gap-2 text-sm font-medium">
              <Checkbox
                checked={draftRelative.isPrimary}
                onCheckedChange={(checked) => updateDraftRelative("isPrimary", Boolean(checked))}
              />
              Primary relative
            </label>
          </div>
          <DialogFooter>
            <DialogClose render={<Button variant="outline">Cancel</Button>} />
            <Button type="button" onClick={saveDraftRelative}>
              {editingRelativeIndex === null ? "Save Relative" : "Update Relative"}
            </Button>
          </DialogFooter>
        </DialogPopup>
      </Dialog>

      <Dialog open={isIdentificationDialogOpen} onOpenChange={setIsIdentificationDialogOpen}>
        <DialogPopup from="right" className="sm:max-w-[620px]">
          <DialogHeader>
            <DialogTitle>
              {editingIdentificationIndex === null ? "Add Identification" : "Edit Identification"}
            </DialogTitle>
            <DialogDescription>
              {editingIdentificationIndex === null
                ? "Capture an identification record and add it."
                : "Update the selected identification record."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 md:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="draft-identification-type">Identification Type</Label>
              <Select
                value={draftIdentification.identificationType}
                onValueChange={(value) =>
                  updateDraftIdentification("identificationType", value ?? "national_id")
                }
              >
                <SelectTrigger id="draft-identification-type">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {IDENTIFICATION_TYPE_OPTIONS.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-identification-number">Identification Number</Label>
              <Input
                id="draft-identification-number"
                value={draftIdentification.identificationNumber}
                onChange={(event) => updateDraftIdentification("identificationNumber", event.target.value)}
                placeholder="ID number"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-identification-country">Issued Country</Label>
              <Input
                id="draft-identification-country"
                value={draftIdentification.issuedCountry}
                onChange={(event) => updateDraftIdentification("issuedCountry", event.target.value)}
                placeholder="Issued country"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-identification-expiry">Expiry Date</Label>
              <DatePickerPresets
                id="draft-identification-expiry"
                value={draftIdentification.expiryDate}
                onChange={(value) => updateDraftIdentification("expiryDate", value)}
                placeholder="Expiry date"
              />
            </div>
            <label className="inline-flex items-center gap-2 text-sm font-medium md:col-span-2">
              <Checkbox
                checked={draftIdentification.isPrimary}
                onCheckedChange={(checked) => updateDraftIdentification("isPrimary", Boolean(checked))}
              />
              Primary identification
            </label>
          </div>
          <DialogFooter>
            <DialogClose render={<Button variant="outline">Cancel</Button>} />
            <Button type="button" onClick={saveDraftIdentification}>
              {editingIdentificationIndex === null ? "Save Identification" : "Update Identification"}
            </Button>
          </DialogFooter>
        </DialogPopup>
      </Dialog>

      <Dialog open={isBankDialogOpen} onOpenChange={setIsBankDialogOpen}>
        <DialogPopup from="right" className="sm:max-w-[640px]">
          <DialogHeader>
            <DialogTitle>{editingBankIndex === null ? "Add Bank Account" : "Edit Bank Account"}</DialogTitle>
            <DialogDescription>
              {editingBankIndex === null
                ? "Capture bank or mobile money account details."
                : "Update the selected bank account details."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            <div className="md:col-span-2 xl:col-span-3">
              <Label className="flex items-center gap-x-3 text-sm font-medium">
                <Switch
                  checked={isDraftBankMobileMoney}
                  onCheckedChange={(checked) => setDraftBankMode(Boolean(checked))}
                />
                {isDraftBankMobileMoney ? "Mobile money account" : "Bank account"}
              </Label>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-bank-name">
                {isDraftBankMobileMoney ? "Mobile Money Provider" : "Bank Name"}
              </Label>
              {isDraftBankMobileMoney ? (
                <Select
                  value={draftBankAccount.mobileMoneyProvider}
                  onValueChange={(value) => {
                    const nextProvider =
                      value && value !== "none" ? value : DEFAULT_MOBILE_MONEY_PROVIDER
                    updateDraftBankAccount("mobileMoneyProvider", nextProvider)
                    updateDraftBankAccount("bankName", nextProvider)
                  }}
                >
                  <SelectTrigger id="draft-bank-name">
                    <SelectValue placeholder="Select provider" />
                  </SelectTrigger>
                  <SelectContent>
                    {MOBILE_MONEY_PROVIDER_OPTIONS.filter((option) => option !== "none").map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Input
                  id="draft-bank-name"
                  value={draftBankAccount.bankName}
                  onChange={(event) => updateDraftBankAccount("bankName", event.target.value)}
                  placeholder="Bank name"
                />
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-bank-account-name">Account Name</Label>
              <Input
                id="draft-bank-account-name"
                value={draftBankAccount.accountName}
                onChange={(event) => updateDraftBankAccount("accountName", event.target.value)}
                placeholder="Account name"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-bank-account-number">
                {isDraftBankMobileMoney ? "Phone Number" : "Account Number"}
              </Label>
              <Input
                id="draft-bank-account-number"
                value={draftBankAccount.accountNumber}
                onChange={(event) => updateDraftBankAccount("accountNumber", event.target.value)}
                placeholder={isDraftBankMobileMoney ? "Phone number" : "Account number"}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-bank-branch">
                Branch Name{isDraftBankMobileMoney ? " (optional)" : ""}
              </Label>
              <Input
                id="draft-bank-branch"
                value={draftBankAccount.branchName}
                onChange={(event) => updateDraftBankAccount("branchName", event.target.value)}
                placeholder="Branch name"
                disabled={isDraftBankMobileMoney}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-bank-swift">SWIFT Code (optional)</Label>
              <Input
                id="draft-bank-swift"
                value={draftBankAccount.swiftCode}
                onChange={(event) => updateDraftBankAccount("swiftCode", event.target.value)}
                placeholder="SWIFT code"
              />
            </div>
            <label className="inline-flex items-center gap-2 text-sm font-medium md:col-span-2 xl:col-span-3">
              <Checkbox
                checked={draftBankAccount.isPrimary}
                onCheckedChange={(checked) => updateDraftBankAccount("isPrimary", Boolean(checked))}
              />
              Primary bank account
            </label>
          </div>
          <DialogFooter>
            <DialogClose render={<Button variant="outline">Cancel</Button>} />
            <Button type="button" onClick={saveDraftBankAccount}>
              {editingBankIndex === null ? "Save Bank Account" : "Update Bank Account"}
            </Button>
          </DialogFooter>
        </DialogPopup>
      </Dialog>

      <Dialog open={isContactDialogOpen} onOpenChange={setIsContactDialogOpen}>
        <DialogPopup from="right" className="sm:max-w-[520px]">
          <DialogHeader>
            <DialogTitle>{editingContactIndex === null ? "Add Contact" : "Edit Contact"}</DialogTitle>
            <DialogDescription>
              {editingContactIndex === null
                ? "Capture a contact and save it to the contacts list."
                : "Update the selected contact."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3">
            <div className="grid gap-2">
              <Label htmlFor="draft-contact-type">Contact Type</Label>
              <Select
                value={draftContact.contactType}
                onValueChange={(value) => updateDraftContact("contactType", value ?? "personal")}
              >
                <SelectTrigger id="draft-contact-type">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {CONTACT_TYPE_OPTIONS.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-contact-phone">Phone Number</Label>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-[minmax(9rem,11rem)_minmax(0,1fr)]">
                <ReactFlagsSelect
                  id="draft-contact-country"
                  rfsKey="draft-contact-country"
                  selected={draftContact.countryIso}
                  onSelect={(value) => updateDraftContact("countryIso", value)}
                  customLabels={COUNTRY_LABELS}
                  searchable
                  searchPlaceholder="Search country"
                  fullWidth
                  showSelectedLabel={false}
                  showOptionLabel
                  showSecondarySelectedLabel
                  showSecondaryOptionLabel
                  selectButtonClassName={cn(
                    "!h-9 !w-full !min-w-0 !rounded-md !border !px-2.5 !py-1.5 !text-sm !shadow-none",
                    draftContactPhoneError ? "!border-destructive" : "!border-input"
                  )}
                  className="w-full min-w-0"
                />
                <Input
                  id="draft-contact-phone"
                  value={draftContact.phoneNumber}
                  className={cn(
                    draftContactPhoneError
                      ? "border-destructive text-destructive focus-visible:border-destructive focus-visible:ring-destructive/30"
                      : undefined
                  )}
                  onChange={(event) => {
                    updateDraftContactPhone(event.target.value)
                    if (draftContactEmailError) {
                      setDraftContactEmailError("")
                    }
                  }}
                  placeholder="712345678"
                />
              </div>
              {draftContactPhoneError ? (
                <p className="text-xs text-destructive">{draftContactPhoneError}</p>
              ) : null}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-contact-email">Email</Label>
              <Input
                id="draft-contact-email"
                type="email"
                value={draftContact.email}
                className={cn(
                  draftContactEmailError
                    ? "border-destructive text-destructive focus-visible:border-destructive focus-visible:ring-destructive/30"
                    : undefined
                )}
                onChange={(event) => {
                  updateDraftContact("email", event.target.value)
                  if (draftContactEmailError) {
                    setDraftContactEmailError("")
                  }
                  if (draftContactPhoneError) {
                    setDraftContactPhoneError("")
                  }
                }}
                placeholder="user@example.com"
              />
              {draftContactEmailError ? (
                <p className="text-xs text-destructive">{draftContactEmailError}</p>
              ) : null}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="draft-contact-notes">Notes (optional)</Label>
              <Input
                id="draft-contact-notes"
                value={draftContact.notes}
                onChange={(event) => updateDraftContact("notes", event.target.value)}
                placeholder="Additional notes"
              />
            </div>
            <label className="inline-flex items-center gap-2 text-sm font-medium">
              <Checkbox
                checked={draftContact.isPrimary}
                onCheckedChange={(checked) => updateDraftContact("isPrimary", Boolean(checked))}
              />
              Primary contact
            </label>
          </div>
          <DialogFooter>
            <DialogClose render={<Button variant="outline">Cancel</Button>} />
            <Button type="button" onClick={saveDraftContact}>
              {editingContactIndex === null ? "Save Contact" : "Update Contact"}
            </Button>
          </DialogFooter>
        </DialogPopup>
      </Dialog>
    </div>
  )
}
